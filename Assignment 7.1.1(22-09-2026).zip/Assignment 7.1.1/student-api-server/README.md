# student-api-server

A beginner-friendly College Student Management REST API built with Node.js, Express, and JSON Web Tokens.

## 1. Create the project in VS Code

1. Open VS Code.
2. Open the integrated terminal with **Terminal > New Terminal**.
3. Run these commands:

```text
mkdir student-api-server
cd student-api-server
npm init -y
npm install express jsonwebtoken
npm install --save-dev nodemon
```

The commands install Express for the server, jsonwebtoken for login tokens, and Nodemon to restart the server when code changes.

## 2. Create the files

Create `server.js` in the project folder and paste the complete server code from this project into it. Update `package.json` so its main entry point is `server.js` and its scripts contain:

```json
"scripts": {
  "dev": "nodemon server.js",
  "start": "nodemon server.js"
}
```

The complete files are already included in this folder, so the project can be started with:

```text
npm run dev
```

Expected terminal message:

```text
Secure Student API server is running at http://localhost:3000
```

Open [http://localhost:3000/app](http://localhost:3000/app) to use the browser dashboard. The root URL `/` intentionally remains a JSON API health response for API testing.

## 3. API testing with Postman or Thunder Client

For every request below, use `http://localhost:3000` as the base URL. Select **JSON** as the body type for requests with a body.

| Step | Method and URL | Body or header | Expected result |
|---|---|---|---|
| A. Register admin | `POST /register` | `{ "username": "admin1", "password": "admin123", "role": "admin" }` | `201`, registration successful |
| B. Register student | `POST /register` | `{ "username": "student1", "password": "123456", "role": "student" }` | `201`, registration successful |
| C. Login | `POST /login` | `{ "username": "admin1", "password": "admin123" }` | `200`, login successful with a JWT |
| D. Copy token | No request | Copy the `token` value from the login response | Use it in the protected requests |
| E. View students | `GET /students` | `Authorization: Bearer <ADMIN_JWT_TOKEN>` | `200`, sample students are returned |
| F. Add student as admin | `POST /students` | Header above; `{ "name": "Priya Nair", "age": 20, "course": "Electronics", "email": "priya@example.com" }` | `201`, new student returned |
| G. Add student as student | `POST /students` | `Authorization: Bearer <STUDENT_JWT_TOKEN>` and the body from F | `403`, `{ "error": "Admin access required" }` |
| H. View without token | `GET /students` | No Authorization header | `401`, `{ "error": "Authentication token required" }` |
| I. View with invalid token | `GET /students` | `Authorization: Bearer invalid-token` | `401`, `{ "error": "Invalid or expired token" }` |
| J. View one student | `GET /students/1` | `Authorization: Bearer <JWT_TOKEN>` | `200`, student with ID 1 |
| K. Unavailable route | `GET /unknown-route` | No body required | `404`, `{ "error": "Route not found" }` |

To get the student token for step G, repeat step C with:

```json
{
  "username": "student1",
  "password": "123456"
}
```

## 4. Example responses

Root endpoint:

```json
{
  "message": "Welcome to Secure Student API"
}
```

Successful login:

```json
{
  "message": "Login successful",
  "token": "<JWT_TOKEN>"
}
```

The optional admin-only `DELETE /students/:id` endpoint uses the admin token and returns `404` with `Student not found` when the ID does not exist.

## 5. How JWT authentication works

`POST /login` checks the in-memory user list. After a successful check, the server signs a token containing `userId`, `username`, and `role`. The client sends that token in the `Authorization` header as `Bearer <JWT_TOKEN>`.

The authentication middleware verifies the token and stores its decoded information in `req.user`. Student routes require this middleware. The reusable admin middleware then checks `req.user.role` before allowing a student to be added or deleted.

## 6. Security and classroom limitations

This assignment uses `const JWT_SECRET = "student_api_secret"` as a placeholder. A real application must read the secret from an environment variable and should use a strong randomly generated value. Passwords are stored as plain text in memory only to keep this classroom example simple. Production applications must hash passwords and use a database or another persistent, protected store.

## 7. Common errors and fixes

- **`npm` is not recognized:** Install Node.js from the official Node.js website, restart VS Code, and try again.
- **Port 3000 is already in use:** Stop the other process using port 3000, or change the `PORT` constant in `server.js` and use the new URL.
- **401 Authentication token required:** Add `Authorization` under the request Headers tab with value `Bearer <copied-token>`.
- **401 Invalid or expired token:** Log in again and copy only the token string, without quotes or the word `Bearer` inside the token value.
- **403 Admin access required:** Use the JWT created by an account registered with role `admin` for POST or DELETE student requests.
- **Data disappeared:** The arrays are in memory, so restarting Nodemon clears registered users and newly added students.
