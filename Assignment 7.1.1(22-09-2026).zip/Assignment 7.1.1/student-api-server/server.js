const express = require("express");
const jwt = require("jsonwebtoken");
const path = require("path");

const app = express();
const PORT = 3000;

// This is a classroom placeholder. Use an environment variable in production.
const JWT_SECRET = "student_api_secret";

// In-memory data is reset whenever the server restarts.
const users = [];
const students = [
  {
    id: 1,
    name: "Ananya Sharma",
    age: 20,
    course: "Computer Science",
    email: "ananya@example.com",
  },
  {
    id: 2,
    name: "Rahul Verma",
    age: 21,
    course: "Information Technology",
    email: "rahul@example.com",
  },
];

app.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.originalUrl}`);
  next();
});

app.use(express.json());
app.use("/app", express.static(path.join(__dirname, "public")));

function authenticateToken(req, res, next) {
  const authorizationHeader = req.headers.authorization;

  if (!authorizationHeader) {
    return res.status(401).json({ error: "Authentication token required" });
  }

  const [scheme, token] = authorizationHeader.split(" ");

  if (scheme !== "Bearer" || !token) {
    return res.status(401).json({ error: "Authentication token required" });
  }

  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch (error) {
    return res.status(401).json({ error: "Invalid or expired token" });
  }
}

function requireAdmin(req, res, next) {
  if (req.user.role !== "admin") {
    return res.status(403).json({ error: "Admin access required" });
  }

  next();
}

app.get("/", (req, res) => {
  res.json({ message: "Welcome to Secure Student API" });
});

app.post("/register", (req, res) => {
  const { username, password, role } = req.body;

  if (!username || !password || !role || !["admin", "student"].includes(role)) {
    return res.status(400).json({ error: "Invalid request" });
  }

  const usernameExists = users.some((user) => user.username === username);
  if (usernameExists) {
    return res.status(400).json({ error: "Username already exists" });
  }

  const newUser = {
    userId: users.length + 1,
    username,
    password,
    role,
  };
  users.push(newUser);

  res.status(201).json({
    message: "Registration successful",
    user: {
      userId: newUser.userId,
      username: newUser.username,
      role: newUser.role,
    },
  });
});

app.post("/login", (req, res) => {
  const { username, password } = req.body;
  const user = users.find(
    (savedUser) => savedUser.username === username && savedUser.password === password
  );

  if (!user) {
    return res.status(401).json({ error: "Invalid username or password" });
  }

  const token = jwt.sign(
    {
      userId: user.userId,
      username: user.username,
      role: user.role,
    },
    JWT_SECRET,
    { expiresIn: "1h" }
  );

  res.json({ message: "Login successful", token });
});

app.get("/students", authenticateToken, (req, res) => {
  res.json(students);
});

app.post("/students", authenticateToken, requireAdmin, (req, res) => {
  const { name, age, course, email } = req.body;

  if (!name || age === undefined || !course || !email || Number.isNaN(Number(age))) {
    return res.status(400).json({ error: "Invalid request" });
  }

  const newStudent = {
    id: students.length > 0 ? Math.max(...students.map((student) => student.id)) + 1 : 1,
    name,
    age: Number(age),
    course,
    email,
  };
  students.push(newStudent);

  res.status(201).json({ message: "Student created successfully", student: newStudent });
});

app.get("/students/:id", authenticateToken, (req, res) => {
  const student = students.find((item) => item.id === Number(req.params.id));

  if (!student) {
    return res.status(404).json({ error: "Student not found" });
  }

  res.json(student);
});

app.delete("/students/:id", authenticateToken, requireAdmin, (req, res) => {
  const studentIndex = students.findIndex((item) => item.id === Number(req.params.id));

  if (studentIndex === -1) {
    return res.status(404).json({ error: "Student not found" });
  }

  const deletedStudent = students.splice(studentIndex, 1)[0];
  res.json({ message: "Student deleted successfully", student: deletedStudent });
});

app.use((req, res) => {
  res.status(404).json({ error: "Route not found" });
});

app.use((error, req, res, next) => {
  if (error instanceof SyntaxError && error.status === 400 && "body" in error) {
    return res.status(400).json({ error: "Invalid request" });
  }

  next(error);
});

app.listen(PORT, () => {
  console.log(`Secure Student API server is running at http://localhost:${PORT}`);
});
