import { useMemo, useState } from 'react'
import Header from './components/Header'
import SearchBar from './components/SearchBar'
import Category from './components/Category'
import BookList from './components/BookList'
import Footer from './components/Footer'
import './App.css'

const books = [
  { id: 1, title: 'The Midnight Library', author: 'Matt Haig', price: 16.99, category: 'Fiction', rating: 4.8, color: 'blue', tag: 'Staff pick' },
  { id: 2, title: 'Atomic Habits', author: 'James Clear', price: 18.5, category: 'Self-help', rating: 4.9, color: 'orange', tag: 'Bestseller' },
  { id: 3, title: 'Braiding Sweetgrass', author: 'Robin Wall Kimmerer', price: 21, category: 'Nature', rating: 4.7, color: 'green', tag: 'New arrival' },
  { id: 4, title: 'Tomorrow, and Tomorrow, and Tomorrow', author: 'Gabrielle Zevin', price: 17.25, category: 'Fiction', rating: 4.6, color: 'pink', tag: 'Reader favorite' },
  { id: 5, title: 'The Creative Act', author: 'Rick Rubin', price: 24, category: 'Creativity', rating: 4.8, color: 'purple', tag: "Editor's note" },
  { id: 6, title: 'A Brief History of Time', author: 'Stephen Hawking', price: 14.75, category: 'Science', rating: 4.5, color: 'yellow', tag: 'Classic' },
]

function App() {
  const [query, setQuery] = useState('')
  const [activeCategory, setActiveCategory] = useState('All books')
  const categories = ['All books', ...new Set(books.map((book) => book.category))]
  const filteredBooks = useMemo(() => books.filter((book) => {
    const matchesCategory = activeCategory === 'All books' || book.category === activeCategory
    const searchText = `${book.title} ${book.author} ${book.category}`.toLowerCase()
    return matchesCategory && searchText.includes(query.toLowerCase())
  }), [activeCategory, query])

  return (
    <div className="app-shell">
      <Header />
      <main>
        <section className="hero-section" aria-labelledby="welcome-title">
          <div className="hero-copy"><p className="eyebrow">Curated for curious minds</p><h1 id="welcome-title">Welcome to<br /><em>Online Book Store</em></h1><p className="hero-description">A considered collection of stories, ideas, and beautiful places to get lost in.</p></div>
          <div className="hero-note"><span>01</span><p>Books that stay<br />with you.</p></div>
        </section>
        <section className="catalog-section" aria-labelledby="catalog-title">
          <div className="section-heading"><div><p className="eyebrow">The collection</p><h2 id="catalog-title">Find your next<br /><em>good read.</em></h2></div><SearchBar query={query} onQueryChange={setQuery} /></div>
          <Category categories={categories} activeCategory={activeCategory} onSelect={setActiveCategory} />
          <BookList books={filteredBooks} />
        </section>
      </main>
      <Footer />
    </div>
  )
}

export default App
