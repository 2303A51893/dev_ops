import Rating from './Rating'
import './BookCard.css'

function BookCard({ book }) { return <article className="book-card"><div className={`cover ${book.color}`}><span className="book-tag">{book.tag}</span><h3>{book.title}</h3></div><div className="book-info"><div className="book-meta"><h3>{book.title}</h3><Rating value={book.rating} /></div><p className="author">{book.author} <span>·</span> {book.category}</p><span className="price">${book.price.toFixed(2)}</span><div className="card-actions"><button type="button">View details</button><button className="buy-button" type="button">Buy now</button></div></div></article> }

export default BookCard