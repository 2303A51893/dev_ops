import BookCard from './BookCard'
import './BookList.css'

function BookList({ books }) { if (!books.length) return <p className="empty-state">No books found. Try another search.</p>; return <div className="book-grid" id="collection">{books.map((book) => <BookCard book={book} key={book.id} />)}</div> }

export default BookList