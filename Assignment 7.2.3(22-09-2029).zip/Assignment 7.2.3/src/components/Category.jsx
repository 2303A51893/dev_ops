import './Category.css'

function Category({ categories, activeCategory, onSelect }) { return <div className="category-nav" id="categories" aria-label="Book categories">{categories.map((category) => <button className={`category-button ${activeCategory === category ? 'active' : ''}`} key={category} onClick={() => onSelect(category)}>{category}</button>)}</div> }

export default Category