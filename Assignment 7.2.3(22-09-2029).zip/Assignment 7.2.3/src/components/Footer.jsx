import './Footer.css'

function Footer() { return <footer className="site-footer" id="about"><span>Chapter° / Online Book Store</span><span>For readers, by readers.</span><span>© 2025</span></footer> }

export default Footer