import './Header.css'

function Header() { return <header className="site-header"><a className="brand" href="#top">Chapter<span>°</span></a><nav aria-label="Main navigation"><a href="#collection">Collection</a><a href="#categories">Categories</a><a href="#about">About us</a></nav><a className="bag-link" href="#collection" aria-label="Shopping bag">Bag <span>0</span></a></header> }

export default Header