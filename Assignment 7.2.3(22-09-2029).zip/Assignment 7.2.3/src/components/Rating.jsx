function Rating({ value }) { return <span className="rating" aria-label={`${value} out of 5 stars`}>★ {value}</span> }

export default Rating