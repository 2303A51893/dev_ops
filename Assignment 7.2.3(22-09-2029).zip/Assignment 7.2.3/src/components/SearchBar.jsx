import './SearchBar.css'

function SearchBar({ query, onQueryChange }) { return <label className="search-bar" htmlFor="book-search"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true"><circle cx="11" cy="11" r="7" /><path d="m16.5 16.5 4 4" /></svg><input id="book-search" value={query} onChange={(event) => onQueryChange(event.target.value)} placeholder="Search by title, author..." /></label> }

export default SearchBar