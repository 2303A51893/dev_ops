import { useState } from 'react'
import './App.css'

const products = [
  {
    id: 1,
    name: 'Cloud Knit Sweater',
    category: 'Apparel',
    price: 48,
    color: 'coral',
    image: 'https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?auto=format&fit=crop&w=700&q=85',
  },
  {
    id: 2,
    name: 'Everyday Canvas Tote',
    category: 'Accessories',
    price: 32,
    color: 'blue',
    image: 'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=700&q=85',
  },
  {
    id: 3,
    name: 'Luna Ceramic Mug',
    category: 'Home',
    price: 24,
    color: 'cream',
    image: 'https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?auto=format&fit=crop&w=700&q=85',
  },
  {
    id: 4,
    name: 'Sunday Leather Slides',
    category: 'Footwear',
    price: 68,
    color: 'green',
    image: 'https://images.unsplash.com/photo-1562273138-f46be4ebdf33?auto=format&fit=crop&w=700&q=85',
  },
]

function Header({ cartCount }) {
  return (
    <header className="site-header">
      <a className="brand" href="#top" aria-label="Loom home">
        <span className="brand-mark">L</span>
        <span>loom</span>
      </a>
      <nav aria-label="Primary navigation">
        <a href="#shop">Shop</a>
        <a href="#about">Our story</a>
      </nav>
      <a className="cart-link" href="#cart">
        Bag <span className="cart-count">{cartCount}</span>
      </a>
    </header>
  )
}

function ProductCard({ product, onAdd }) {
  return (
    <article className="product-card">
      <div className={`product-image ${product.color}`}>
        <img src={product.image} alt={product.name} />
        <span className="category">{product.category}</span>
      </div>
      <div className="product-details">
        <div>
          <h3>{product.name}</h3>
          <p className="price">${product.price}</p>
        </div>
        <button className="add-button" type="button" onClick={() => onAdd(product)}>
          <span aria-hidden="true">+</span> Add
        </button>
      </div>
    </article>
  )
}

function ProductList({ products: productItems, onAdd }) {
  return (
    <section className="shop-section" id="shop">
      <div className="section-heading">
        <div>
          <p className="eyebrow">Curated for daily rituals</p>
          <h2>Small things,<br /><em>well made.</em></h2>
        </div>
        <p className="section-note">Thoughtful objects for the way<br />you live, work, and unwind.</p>
      </div>
      <div className="product-grid">
        {productItems.map((product) => (
          <ProductCard key={product.id} product={product} onAdd={onAdd} />
        ))}
      </div>
    </section>
  )
}

function Cart({ cart, onRemove, onIncrease, onDecrease, onClear }) {
  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0)

  return (
    <aside className="cart-panel" id="cart">
      <div className="cart-heading">
        <div>
          <p className="eyebrow">Your selection</p>
          <h2>Your bag <span>({cart.reduce((sum, item) => sum + item.quantity, 0)})</span></h2>
        </div>
        {cart.length > 0 && <button className="clear-button" type="button" onClick={onClear}>Clear all</button>}
      </div>
      {cart.length === 0 ? (
        <div className="empty-cart">
          <span className="empty-icon">○</span>
          <p>Cart is Empty</p>
          <span>Add something lovely to get started.</span>
        </div>
      ) : (
        <>
          <div className="cart-items">
            {cart.map((item) => (
              <div className="cart-item" key={item.id}>
                <img src={item.image} alt="" />
                <div className="cart-item-info">
                  <h3>{item.name}</h3>
                  <p>${item.price}</p>
                  <div className="quantity-controls">
                    <button type="button" onClick={() => onDecrease(item.id)} aria-label={`Decrease ${item.name} quantity`}>−</button>
                    <span>{item.quantity}</span>
                    <button type="button" onClick={() => onIncrease(item.id)} aria-label={`Increase ${item.name} quantity`}>+</button>
                  </div>
                </div>
                <button className="remove-button" type="button" onClick={() => onRemove(item.id)}>Remove</button>
              </div>
            ))}
          </div>
          <div className="cart-summary">
            <div><span>Subtotal</span><strong>${total.toFixed(2)}</strong></div>
            <p>Shipping calculated at checkout</p>
            <button className="checkout-button" type="button">Checkout <span>→</span></button>
          </div>
        </>
      )}
    </aside>
  )
}

function Footer() {
  return <footer id="about"><span>© 2026 loom studio</span><span>Made for the everyday.</span><span>Good objects, good days.</span></footer>
}

function App() {
  const [cart, setCart] = useState([])
  const [notice, setNotice] = useState('')

  const addToCart = (product) => {
    setCart((currentCart) => {
      const existing = currentCart.find((item) => item.id === product.id)
      if (existing) return currentCart.map((item) => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item)
      return [...currentCart, { ...product, quantity: 1 }]
    })
    setNotice(`${product.name} added to your bag`)
    window.setTimeout(() => setNotice(''), 2200)
  }

  const updateQuantity = (id, amount) => setCart((currentCart) => currentCart.flatMap((item) => {
    if (item.id !== id) return [item]
    const quantity = item.quantity + amount
    return quantity > 0 ? [{ ...item, quantity }] : []
  }))

  const removeFromCart = (id) => setCart((currentCart) => currentCart.filter((item) => item.id !== id))

  return (
    <div id="top">
      <Header cartCount={cart.reduce((sum, item) => sum + item.quantity, 0)} />
      <main>
        <section className="hero">
          <div className="hero-copy">
            <p className="eyebrow">The considered collection / 01</p>
            <h1>Welcome to<br /><em>Online Shopping.</em></h1>
            <p className="hero-description">Objects with a point of view,<br />made to find a place in yours.</p>
            <a className="shop-link" href="#shop">Explore the collection <span>↓</span></a>
          </div>
          <div className="hero-art" aria-hidden="true"><span>LOOM<br /><small>EST. 2026</small></span></div>
        </section>
        <ProductList products={products} onAdd={addToCart} />
        <Cart cart={cart} onRemove={removeFromCart} onIncrease={(id) => updateQuantity(id, 1)} onDecrease={(id) => updateQuantity(id, -1)} onClear={() => setCart([])} />
      </main>
      <Footer />
      {notice && <div className="toast" role="status">{notice}<span>✓</span></div>}
    </div>
  )
}

export default App
