import { useState } from "react";
import Header from "./components/Header.jsx";
import StudentList from "./components/StudentList.jsx";
import Summary from "./components/Summary.jsx";

const initialStudents = [
  { name: "Rahul", rollNumber: "CSE101", branch: "CSE", attendance: 82 },
  { name: "Priya", rollNumber: "CSE102", branch: "CSE", attendance: 68 },
  { name: "Arjun", rollNumber: "CSE103", branch: "CSE", attendance: 91 },
  { name: "Sneha", rollNumber: "CSE104", branch: "CSE", attendance: 74 },
  { name: "Kiran", rollNumber: "CSE105", branch: "CSE", attendance: 88 },
];

function App() {
  // The parent owns attendance so every component displays the same live data.
  const [students, setStudents] = useState(initialStudents);
  const [searchTerm, setSearchTerm] = useState("");

  function updateAttendance(rollNumber, change) {
    // map() creates a new array and changes only the selected student's record.
    setStudents((currentStudents) =>
      currentStudents.map((student) => {
        if (student.rollNumber !== rollNumber) {
          return student;
        }

        return {
          ...student,
          attendance: Math.max(0, Math.min(100, student.attendance + change)),
        };
      }),
    );
  }

  function resetAttendance() {
    // Copy each original record so future updates cannot mutate the reset data.
    setStudents(initialStudents.map((student) => ({ ...student })));
  }

  const normalizedSearch = searchTerm.trim().toLowerCase();
  const filteredStudents = students.filter((student) => {
    return (
      student.name.toLowerCase().includes(normalizedSearch) ||
      student.rollNumber.toLowerCase().includes(normalizedSearch)
    );
  });

  // The assignment tracks percentages rather than a separate daily roll call.
  // Here, 75% is the documented threshold for the present/absent summary counts.
  const summary = students.reduce(
    (counts, student) => {
      if (student.attendance >= 75) {
        counts.presentStudents += 1;
        counts.eligibleStudents += 1;
      } else {
        counts.absentStudents += 1;
        counts.notEligibleStudents += 1;
      }
      return counts;
    },
    {
      presentStudents: 0,
      absentStudents: 0,
      eligibleStudents: 0,
      notEligibleStudents: 0,
    },
  );

  return (
    <div className="app-shell">
      <Header />

      <main className="dashboard">
        <section className="welcome-row" aria-labelledby="overview-heading">
          <div>
            <p className="eyebrow">DEVOPS AND FULLSTACK · ASSIGNMENT 9.1.2</p>
            <h2 id="overview-heading">Attendance overview</h2>
            <p className="welcome-copy">
              Review student records and keep attendance up to date.
            </p>
          </div>
          <button className="reset-button" onClick={resetAttendance} type="button">
            <span aria-hidden="true">↻</span> Reset Attendance
          </button>
        </section>

        <Summary totalStudents={students.length} {...summary} />

        <section className="students-section" aria-labelledby="students-heading">
          <div className="section-heading">
            <div>
              <h2 id="students-heading">Students</h2>
              <p>
                {filteredStudents.length} of {students.length} students
              </p>
            </div>
            <label className="search-box">
              <span className="search-icon" aria-hidden="true">
                ⌕
              </span>
              <span className="visually-hidden">Search by name or roll number</span>
              <input
                type="search"
                placeholder="Search students..."
                value={searchTerm}
                onChange={(event) => setSearchTerm(event.target.value)}
              />
            </label>
          </div>

          {filteredStudents.length > 0 ? (
            <StudentList
              students={filteredStudents}
              onUpdateAttendance={updateAttendance}
            />
          ) : (
            <div className="empty-state">
              <span className="empty-icon" aria-hidden="true">
                ⌕
              </span>
              <h3>No students found</h3>
              <p>Try searching with a different name or roll number.</p>
            </div>
          )}
        </section>

        <p className="summary-note">
          Present and absent summary counts use the 75% attendance threshold.
        </p>
      </main>

      <footer className="page-footer">
        <span>College Student Attendance Dashboard</span>
        <span>Built with React</span>
      </footer>
    </div>
  );
}

export default App;
