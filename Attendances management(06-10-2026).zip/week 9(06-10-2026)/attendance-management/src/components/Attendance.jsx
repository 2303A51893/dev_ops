function Attendance({ attendance, onPresent, onAbsent }) {
  const isEligible = attendance >= 75;

  return (
    <div className="attendance-section">
      <div className="attendance-heading">
        <span className="attendance-label">ATTENDANCE</span>
        <span className={`attendance-value${isEligible ? "" : " attendance-value--low"}`}>
          {attendance}%
        </span>
      </div>
      <div
        className="progress-track"
        role="progressbar"
        aria-label="Attendance percentage"
        aria-valuemin="0"
        aria-valuemax="100"
        aria-valuenow={attendance}
      >
        <div
          className={`progress-fill${isEligible ? "" : " progress-fill--low"}`}
          style={{ width: `${attendance}%` }}
        />
      </div>
      <div className="attendance-actions">
        <button
          className="attendance-button present-button"
          onClick={onPresent}
          type="button"
          disabled={attendance >= 100}
          aria-label={`Increase ${attendance}% attendance`}
        >
          <span aria-hidden="true">+</span> Present
        </button>
        <button
          className="attendance-button absent-button"
          onClick={onAbsent}
          type="button"
          disabled={attendance <= 0}
          aria-label={`Decrease ${attendance}% attendance`}
        >
          <span aria-hidden="true">−</span> Absent
        </button>
      </div>
    </div>
  );
}

export default Attendance;
