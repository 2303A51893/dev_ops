function Header() {
  return (
    <header className="app-header">
      <a className="brand" href="/" aria-label="Attendance dashboard home">
        <span className="brand-mark" aria-hidden="true">
          <svg viewBox="0 0 24 24" fill="none">
            <path
              d="M7 3.75h10A2.25 2.25 0 0 1 19.25 6v14.25H4.75V6A2.25 2.25 0 0 1 7 3.75Z"
              stroke="currentColor"
              strokeWidth="1.7"
              strokeLinejoin="round"
            />
            <path
              d="M8 8h8M8 12h2.5l1.5 1.5 3.5-3.5M8 17h8"
              stroke="currentColor"
              strokeWidth="1.7"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </span>
        <h1 className="brand-name">Student Attendance Management System</h1>
      </a>
      <div className="header-context">
        <span className="header-dot" aria-hidden="true" />
        <span>College Dashboard</span>
      </div>
    </header>
  );
}

export default Header;
