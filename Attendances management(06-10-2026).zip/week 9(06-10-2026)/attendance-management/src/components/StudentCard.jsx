import Attendance from "./Attendance.jsx";

function StudentCard({
  name,
  rollNumber,
  branch,
  attendance,
  onPresent,
  onAbsent,
}) {
  const isEligible = attendance >= 75;
  const initials = name
    .split(" ")
    .map((part) => part[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();

  return (
    <article className={`student-card${isEligible ? "" : " student-card--low"}`}>
      <div className="student-card-top">
        <div className="student-identity">
          <div className={`avatar${isEligible ? "" : " avatar--low"}`} aria-hidden="true">
            {initials}
          </div>
          <div>
            <h3>{name}</h3>
            <p className="roll-number">{rollNumber}</p>
          </div>
        </div>
        <span className={`status-badge${isEligible ? "" : " status-badge--low"}`}>
          <span className="status-dot" aria-hidden="true" />
          {isEligible ? "Eligible" : "Not Eligible"}
        </span>
      </div>

      <div className="student-meta">
        <span className="meta-label">BRANCH</span>
        <span className="branch-value">
          <span className="branch-icon" aria-hidden="true">
            ◈
          </span>
          {branch}
        </span>
      </div>

      <Attendance
        attendance={attendance}
        onPresent={onPresent}
        onAbsent={onAbsent}
      />
    </article>
  );
}

export default StudentCard;
