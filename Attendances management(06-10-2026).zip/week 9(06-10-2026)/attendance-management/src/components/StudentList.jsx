import StudentCard from "./StudentCard.jsx";

function StudentList({ students, onUpdateAttendance }) {
  return (
    <div className="student-grid">
      {students.map((student) => (
        <StudentCard
          key={student.rollNumber}
          name={student.name}
          rollNumber={student.rollNumber}
          branch={student.branch}
          attendance={student.attendance}
          onPresent={() => onUpdateAttendance(student.rollNumber, 1)}
          onAbsent={() => onUpdateAttendance(student.rollNumber, -1)}
        />
      ))}
    </div>
  );
}

export default StudentList;
