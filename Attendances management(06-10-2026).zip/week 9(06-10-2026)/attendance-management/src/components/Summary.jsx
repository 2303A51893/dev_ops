const summaryCards = [
  {
    key: "totalStudents",
    label: "Total Students",
    icon: "◎",
    tone: "blue",
  },
  {
    key: "presentStudents",
    label: "Present Students",
    icon: "✓",
    tone: "green",
  },
  {
    key: "absentStudents",
    label: "Absent Students",
    icon: "−",
    tone: "red",
  },
  {
    key: "eligibleStudents",
    label: "Eligible",
    icon: "↗",
    tone: "violet",
  },
  {
    key: "notEligibleStudents",
    label: "Not Eligible",
    icon: "!",
    tone: "amber",
  },
];

function Summary({
  totalStudents,
  presentStudents,
  absentStudents,
  eligibleStudents,
  notEligibleStudents,
}) {
  const values = {
    totalStudents,
    presentStudents,
    absentStudents,
    eligibleStudents,
    notEligibleStudents,
  };

  return (
    <section className="summary-grid" aria-label="Attendance summary">
      {summaryCards.map((card) => (
        <article className="summary-card" key={card.key}>
          <span className={`summary-icon summary-icon--${card.tone}`} aria-hidden="true">
            {card.icon}
          </span>
          <div className="summary-content">
            <span className="summary-label">{card.label}</span>
            <strong className="summary-value">{values[card.key]}</strong>
          </div>
        </article>
      ))}
    </section>
  );
}

export default Summary;
