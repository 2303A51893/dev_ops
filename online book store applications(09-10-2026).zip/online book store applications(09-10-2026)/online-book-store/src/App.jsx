import { useCallback, useState } from "react";
import { Route, Routes } from "react-router-dom";
import Header from "./components/Header.jsx";
import Navigation from "./components/Navigation.jsx";
import BookList from "./components/BookList.jsx";
import Home from "./pages/Home.jsx";
import BookDetails from "./pages/BookDetails.jsx";
import Categories from "./pages/Categories.jsx";
import Cart from "./pages/Cart.jsx";
import Profile from "./pages/Profile.jsx";
import NotFound from "./pages/NotFound.jsx";
import { books } from "./data/books.js";

function App() {
  const [cartItems, setCartItems] = useState([]);
  const [recentlyViewed, setRecentlyViewed] = useState([]);

  const addToCart = useCallback((book) => {
    setCartItems((currentItems) => {
      const existingItem = currentItems.find(
        (item) => item.bookId === book.bookId,
      );

      if (existingItem) {
        return currentItems.map((item) =>
          item.bookId === book.bookId
            ? { ...item, quantity: item.quantity + 1 }
            : item,
        );
      }

      return [...currentItems, { ...book, quantity: 1 }];
    });
  }, []);

  const removeFromCart = useCallback((bookId) => {
    setCartItems((currentItems) =>
      currentItems.filter((item) => item.bookId !== bookId),
    );
  }, []);

  const decreaseCartQuantity = useCallback((bookId) => {
    setCartItems((currentItems) =>
      currentItems.flatMap((item) => {
        if (item.bookId !== bookId) return [item];
        return item.quantity > 1
          ? [{ ...item, quantity: item.quantity - 1 }]
          : [];
      }),
    );
  }, []);

  const recordRecentlyViewed = useCallback((book) => {
    setRecentlyViewed((currentBooks) => [
      book,
      ...currentBooks.filter((item) => item.bookId !== book.bookId),
    ]);
  }, []);

  return (
    <>
      <Header cartCount={cartItems.reduce((total, item) => total + item.quantity, 0)} />
      <Navigation />
      <main className="page-shell">
        <Routes>
          <Route
            path="/"
            element={
              <Home
                recentlyViewed={recentlyViewed}
                onAddToCart={addToCart}
              />
            }
          />
          <Route
            path="/books"
            element={<BookList books={books} onAddToCart={addToCart} />}
          />
          <Route
            path="/books/:bookId"
            element={
              <BookDetails
                books={books}
                onAddToCart={addToCart}
                onViewBook={recordRecentlyViewed}
              />
            }
          />
          <Route path="/categories" element={<Categories books={books} />} />
          <Route
            path="/cart"
            element={
              <Cart
                items={cartItems}
                onRemove={removeFromCart}
                onDecrease={decreaseCartQuantity}
                onAdd={addToCart}
              />
            }
          />
          <Route path="/profile" element={<Profile />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
      <footer className="site-footer">
        <p>DEVOPS AND FULLSTACK · Assignment 9.2.3</p>
      </footer>
    </>
  );
}

export default App;
