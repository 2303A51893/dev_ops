import { Link } from "react-router-dom";

function BookCard({ book, onAddToCart }) {
  return (
    <article className="book-card">
      <Link
        className={`book-cover ${book.color}`}
        to={`/books/${book.bookId}`}
        aria-label={`View ${book.title}`}
      >
        <span className="cover-kicker">THE LITTLE LIBRARY</span>
        <span className="cover-label">{book.label}</span>
        <span className="cover-title">{book.title}</span>
        <span className="cover-author">{book.author}</span>
      </Link>
      <div className="book-card-content">
        <span className="book-category">{book.category}</span>
        <h3>
          <Link to={`/books/${book.bookId}`}>{book.title}</Link>
        </h3>
        <p className="book-author">by {book.author}</p>
        <div className="book-card-bottom">
          <strong className="price">₹{book.price}</strong>
          <div className="card-actions">
            <Link className="text-link" to={`/books/${book.bookId}`}>
              View Details
            </Link>
            <button
              className="button button-small button-outline"
              type="button"
              onClick={() => onAddToCart(book)}
            >
              Add to Cart
            </button>
          </div>
        </div>
      </div>
    </article>
  );
}

export default BookCard;
