import { useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import BookCard from "./BookCard.jsx";
import { categories } from "../data/books.js";

function BookList({ books, onAddToCart }) {
  const [searchText, setSearchText] = useState("");
  const [searchParams, setSearchParams] = useSearchParams();
  const selectedCategory = searchParams.get("category") || "All";

  const filteredBooks = useMemo(() => {
    const query = searchText.trim().toLowerCase();

    return books.filter((book) => {
      const matchesSearch =
        !query ||
        [book.title, book.author, book.category].some((value) =>
          value.toLowerCase().includes(query),
        );
      const matchesCategory =
        selectedCategory === "All" || book.category === selectedCategory;

      return matchesSearch && matchesCategory;
    });
  }, [books, searchText, selectedCategory]);

  function handleCategoryChange(event) {
    const value = event.target.value;
    setSearchParams(value === "All" ? {} : { category: value });
  }

  return (
    <section className="content-section">
      <div className="section-heading">
        <div>
          <p className="eyebrow">FIND YOUR NEXT FAVORITE</p>
          <h1>Books for curious minds</h1>
          <p className="section-intro">
            Browse the shelves, search by author, or pick a subject to explore.
          </p>
        </div>
        <span className="result-count">{filteredBooks.length} books</span>
      </div>

      <div className="book-filters">
        <label className="search-field">
          <span className="sr-only">Search books</span>
          <span className="search-icon" aria-hidden="true">⌕</span>
          <input
            type="search"
            placeholder="Search books..."
            value={searchText}
            onChange={(event) => setSearchText(event.target.value)}
          />
        </label>
        <label className="category-select">
          <span>Category</span>
          <select value={selectedCategory} onChange={handleCategoryChange}>
            <option>All</option>
            {categories.map((category) => (
              <option key={category}>{category}</option>
            ))}
          </select>
        </label>
      </div>

      {filteredBooks.length > 0 ? (
        <div className="book-grid">
          {filteredBooks.map((book) => (
            <BookCard key={book.bookId} book={book} onAddToCart={onAddToCart} />
          ))}
        </div>
      ) : (
        <div className="empty-state">
          <span className="empty-icon" aria-hidden="true">⌕</span>
          <h2>No books found</h2>
          <p>Try a different search or choose another category.</p>
        </div>
      )}
    </section>
  );
}

export default BookList;
