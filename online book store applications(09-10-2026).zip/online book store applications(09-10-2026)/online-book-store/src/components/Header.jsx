import { Link } from "react-router-dom";

function Header({ cartCount }) {
  return (
    <header className="site-header">
      <div className="header-inner">
        <Link className="brand" to="/" aria-label="Online Book Store home">
          <span className="brand-mark" aria-hidden="true">B</span>
          <span>
            <span className="brand-name">Online Book Store</span>
            <span className="brand-tagline">A little something to read</span>
          </span>
        </Link>
        <Link className="header-cart" to="/cart">
          <span aria-hidden="true">Bag</span>
          <span>Cart ({cartCount})</span>
        </Link>
      </div>
    </header>
  );
}

export default Header;
