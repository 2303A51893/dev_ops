import { NavLink } from "react-router-dom";

const links = [
  { to: "/", label: "Home", end: true },
  { to: "/books", label: "Books" },
  { to: "/categories", label: "Categories" },
  { to: "/cart", label: "Cart" },
  { to: "/profile", label: "Profile" },
];

function Navigation() {
  return (
    <nav className="main-nav" aria-label="Main navigation">
      <div className="nav-inner">
        {links.map((link) => (
          <NavLink
            key={link.to}
            to={link.to}
            end={link.end}
            className={({ isActive }) => (isActive ? "nav-link active" : "nav-link")}
          >
            {link.label}
          </NavLink>
        ))}
      </div>
    </nav>
  );
}

export default Navigation;
