export const books = [
  {
    bookId: "B101",
    title: "Python Programming",
    author: "John Smith",
    category: "Programming",
    price: 499,
    description:
      "A beginner-friendly guide to Python fundamentals, problem solving, and writing your first useful programs.",
    color: "lavender",
    label: "PY",
  },
  {
    bookId: "B102",
    title: "Web Development",
    author: "Sarah Johnson",
    category: "Web Development",
    price: 599,
    description:
      "Learn how the web works and build accessible, responsive pages with HTML, CSS, and JavaScript.",
    color: "peach",
    label: "WEB",
  },
  {
    bookId: "B103",
    title: "Machine Learning",
    author: "David Lee",
    category: "Machine Learning",
    price: 749,
    description:
      "An approachable introduction to machine learning ideas, common algorithms, and practical examples.",
    color: "mint",
    label: "ML",
  },
  {
    bookId: "B104",
    title: "React Development",
    author: "Emily Davis",
    category: "Web Development",
    price: 649,
    description:
      "Build interactive user interfaces by learning components, props, state, and React application patterns.",
    color: "blue",
    label: "R",
  },
  {
    bookId: "B105",
    title: "Data Structures",
    author: "Michael Brown",
    category: "Data Structures",
    price: 549,
    description:
      "Understand essential data structures and algorithms with clear explanations and coding exercises.",
    color: "yellow",
    label: "DS",
  },
];

export const categories = [
  "Programming",
  "Web Development",
  "Machine Learning",
  "Data Structures",
];
