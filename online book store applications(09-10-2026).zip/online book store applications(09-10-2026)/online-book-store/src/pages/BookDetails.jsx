import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";

function BookDetails({ books, onAddToCart, onViewBook }) {
  const { bookId } = useParams();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const book = books.find((item) => item.bookId === bookId);
  const bookIndex = books.findIndex((item) => item.bookId === bookId);

  useEffect(() => {
    console.log("Loading book details");
    setIsLoading(true);

    const timerId = window.setTimeout(() => {
      setIsLoading(false);
      if (book) {
        onViewBook(book);
      }
    }, 450);

    return () => {
      window.clearTimeout(timerId);
      console.log("Leaving book details");
    };
  }, [bookId, book, onViewBook]);

  if (isLoading) {
    return (
      <div className="loading-state" role="status">
        <span className="loading-spinner" aria-hidden="true" />
        <p>Loading book details...</p>
      </div>
    );
  }

  if (!book) {
    return (
      <section className="empty-state">
        <span className="empty-icon" aria-hidden="true">?</span>
        <p className="eyebrow">WE COULDN&apos;T FIND THAT ONE</p>
        <h1>Book Not Found</h1>
        <p>The book ID “{bookId}” does not match a book on our shelf.</p>
        <button
          className="button button-primary"
          type="button"
          onClick={() => navigate("/books")}
        >
          Back to Books
        </button>
      </section>
    );
  }

  return (
    <section className="book-detail">
      <div className={`detail-cover book-cover ${book.color}`}>
        <span className="cover-kicker">THE LITTLE LIBRARY</span>
        <span className="cover-label">{book.label}</span>
        <span className="cover-title">{book.title}</span>
        <span className="cover-author">{book.author}</span>
      </div>
      <div className="detail-copy">
        <Link className="back-link" to="/books">← All books</Link>
        <p className="eyebrow">{book.category} · {book.bookId}</p>
        <h1>{book.title}</h1>
        <p className="detail-author">Written by {book.author}</p>
        <p className="detail-description">{book.description}</p>
        <p className="detail-price">₹{book.price}</p>
        <div className="detail-actions">
          <button
            className="button button-primary"
            type="button"
            onClick={() => onAddToCart(book)}
          >
            Add to Cart
          </button>
          <button
            className="button button-outline"
            type="button"
            onClick={() => navigate("/cart")}
          >
            Go to Cart
          </button>
        </div>
        <div className="book-pager">
          <button
            className="pager-button"
            type="button"
            disabled={bookIndex <= 0}
            onClick={() => navigate(`/books/${books[bookIndex - 1].bookId}`)}
          >
            <span aria-hidden="true">←</span> Previous Book
          </button>
          <button
            className="pager-button"
            type="button"
            disabled={bookIndex === books.length - 1}
            onClick={() => navigate(`/books/${books[bookIndex + 1].bookId}`)}
          >
            Next Book <span aria-hidden="true">→</span>
          </button>
        </div>
      </div>
    </section>
  );
}

export default BookDetails;
