import { Link } from "react-router-dom";

function Cart({ items, onRemove, onDecrease, onAdd }) {
  const total = items.reduce((sum, item) => sum + item.price * item.quantity, 0);

  if (items.length === 0) {
    return (
      <section className="empty-state cart-empty">
        <span className="empty-icon" aria-hidden="true">B</span>
        <p className="eyebrow">ROOM FOR A NEW STORY</p>
        <h1>Your bag is waiting</h1>
        <p>Cart is empty. Browse the shelves and find something to take home.</p>
        <Link className="button button-primary" to="/books">Explore the books</Link>
      </section>
    );
  }

  return (
    <section className="content-section cart-section">
      <div className="section-heading">
        <div>
          <p className="eyebrow">YOUR PICKS</p>
          <h1>Your cart</h1>
        </div>
        <Link className="text-link" to="/books">Continue browsing <span aria-hidden="true">→</span></Link>
      </div>
      <div className="cart-layout">
        <div className="cart-items">
          {items.map((item) => (
            <article className="cart-item" key={item.bookId}>
              <Link
                className={`cart-cover book-cover ${item.color}`}
                to={`/books/${item.bookId}`}
              >
                <span className="cover-label">{item.label}</span>
              </Link>
              <div className="cart-item-info">
                <span className="book-category">{item.category}</span>
                <h2><Link to={`/books/${item.bookId}`}>{item.title}</Link></h2>
                <p className="book-author">by {item.author}</p>
                <button
                  className="remove-button"
                  type="button"
                  onClick={() => onRemove(item.bookId)}
                >
                  Remove
                </button>
              </div>
              <div className="cart-item-price">
                <strong>₹{item.price * item.quantity}</strong>
                <div className="quantity-control" aria-label={`Quantity: ${item.quantity}`}>
                  <button type="button" onClick={() => onDecrease(item.bookId)} aria-label={`Decrease ${item.title} quantity`}>−</button>
                  <span>{item.quantity}</span>
                  <button type="button" onClick={() => onAdd(item)} aria-label={`Add another ${item.title}`}>+</button>
                </div>
                {item.quantity > 1 && <span className="unit-price">₹{item.price} each</span>}
              </div>
            </article>
          ))}
        </div>
        <aside className="order-summary">
          <p className="eyebrow">A LITTLE SUMMARY</p>
          <h2>Order total</h2>
          <div className="summary-line">
            <span>Subtotal</span>
            <span>₹{total}</span>
          </div>
          <div className="summary-line">
            <span>Delivery</span>
            <span className="free-delivery">On us</span>
          </div>
          <div className="summary-total">
            <strong>Total</strong>
            <strong>₹{total}</strong>
          </div>
          <button className="button button-primary checkout-button" type="button" onClick={() => window.alert("Thank you! Checkout is a demo for this assignment.")}>
            Continue to checkout
          </button>
          <p className="checkout-note">This demo does not process real payments.</p>
        </aside>
      </div>
    </section>
  );
}

export default Cart;
