import { Link } from "react-router-dom";
import { categories } from "../data/books.js";

function Categories({ books }) {
  return (
    <section className="content-section">
      <div className="section-heading">
        <div>
          <p className="eyebrow">FOLLOW YOUR CURIOSITY</p>
          <h1>Browse by category</h1>
          <p className="section-intro">
            Choose a subject and we&apos;ll take you to the books on that shelf.
          </p>
        </div>
      </div>
      <div className="category-grid">
        {categories.map((category, index) => {
          const count = books.filter((book) => book.category === category).length;
          return (
            <Link
              className={`category-card category-tone-${index + 1}`}
              key={category}
              to={`/books?category=${encodeURIComponent(category)}`}
            >
              <span className="category-number">0{index + 1}</span>
              <span className="category-card-name">{category}</span>
              <span className="category-card-bottom">
                {count} {count === 1 ? "book" : "books"} <span aria-hidden="true">↗</span>
              </span>
            </Link>
          );
        })}
      </div>
    </section>
  );
}

export default Categories;
