import { Link } from "react-router-dom";
import BookCard from "../components/BookCard.jsx";
import { books } from "../data/books.js";

function Home({ recentlyViewed, onAddToCart }) {
  const featuredBooks = books.slice(0, 3);

  return (
    <>
      <section className="hero">
        <div className="hero-copy">
          <p className="eyebrow">A GOOD BOOK, A QUIETER MOMENT</p>
          <h1>Stories, ideas<br />and <em>new worlds.</em></h1>
          <p className="hero-description">
            Thoughtful reads for wherever your curiosity takes you. Find
            something wonderful on our little bookshelf.
          </p>
          <Link className="button button-primary" to="/books">
            Explore the books <span aria-hidden="true">→</span>
          </Link>
          <p className="hero-note">A small collection, picked with care.</p>
        </div>
        <div className="hero-art" aria-label="A stack of colorful books" role="img">
          <div className="sun-shape" />
          <div className="plant plant-one" />
          <div className="hero-book hero-book-one"><span>little ideas</span></div>
          <div className="hero-book hero-book-two"><span>the art of learning</span></div>
          <div className="hero-book hero-book-three"><span>good things grow</span></div>
          <div className="hero-caption">Your next chapter<br />starts here.</div>
        </div>
      </section>

      <section className="content-section home-featured">
        <div className="section-heading">
          <div>
            <p className="eyebrow">A FEW GOOD PLACES TO START</p>
            <h2>On the bookshelf</h2>
          </div>
          <Link className="text-link" to="/books">See all books <span aria-hidden="true">→</span></Link>
        </div>
        <div className="book-grid">
          {featuredBooks.map((book) => (
            <BookCard key={book.bookId} book={book} onAddToCart={onAddToCart} />
          ))}
        </div>
      </section>

      {recentlyViewed.length > 0 && (
        <section className="content-section recently-viewed">
          <div className="section-heading">
            <div>
              <p className="eyebrow">PICK UP WHERE YOU LEFT OFF</p>
              <h2>Recently viewed</h2>
            </div>
            <Link className="text-link" to="/books">Browse all <span aria-hidden="true">→</span></Link>
          </div>
          <div className="book-grid">
            {recentlyViewed.map((book) => (
              <BookCard key={book.bookId} book={book} onAddToCart={onAddToCart} />
            ))}
          </div>
        </section>
      )}
    </>
  );
}

export default Home;
