import { useNavigate } from "react-router-dom";

function NotFound() {
  const navigate = useNavigate();

  return (
    <section className="empty-state not-found">
      <span className="not-found-number">404</span>
      <p className="eyebrow">THIS PAGE ISN&apos;T ON OUR SHELF</p>
      <h1>Page Not Found</h1>
      <p>That address doesn&apos;t lead to a page in our book store.</p>
      <button
        className="button button-primary"
        type="button"
        onClick={() => navigate("/")}
      >
        Return Home
      </button>
    </section>
  );
}

export default NotFound;
