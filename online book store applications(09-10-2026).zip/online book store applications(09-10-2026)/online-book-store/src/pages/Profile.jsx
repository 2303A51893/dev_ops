import { Link } from "react-router-dom";

function Profile() {
  return (
    <section className="profile-card">
      <div className="profile-avatar" aria-hidden="true">R</div>
      <p className="eyebrow">YOUR LITTLE CORNER</p>
      <h1>Reader Profile</h1>
      <p className="profile-description">
        Welcome, Reader! This sample profile is ready for your favorite books
        and reading notes.
      </p>
      <div className="profile-detail">
        <span>Reader name</span>
        <strong>Book Lover</strong>
      </div>
      <div className="profile-detail">
        <span>Membership</span>
        <strong>Curious Reader</strong>
      </div>
      <Link className="button button-outline" to="/books">Find your next read</Link>
    </section>
  );
}

export default Profile;
