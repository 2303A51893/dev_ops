# Assignment 10.1.2 – Online Shopping Product Management

A responsive React/Vite product dashboard connected to a Node.js/Express REST
API. Products are stored in a backend in-memory array: products you add, edit,
or delete reset to the three sample products whenever the backend restarts.

## Project structure

```text
shopping-frontend/   React application (Vite)
shopping-backend/    Express REST API
```

## Setup

Install [Node.js](https://nodejs.org/) first. Open **two separate terminals**
in this assignment folder and run these commands.

### Terminal 1 – backend

```powershell
cd shopping-backend
npm install
npm run dev
```

The backend installs Express and CORS and listens at `http://localhost:5000`.
Leave this terminal running.

### Terminal 2 – frontend

```powershell
cd shopping-frontend
npm install
npm run dev
```

Open the Vite URL printed in the terminal, usually
`http://localhost:5173`. The browser frontend uses Axios to call the API at
`http://localhost:5000/api`.

## API testing with Postman

Send requests to `http://localhost:5000/api/products`:

1. **GET** `/api/products` to list all sample products.
2. **GET** `/api/products/1` to retrieve the Laptop.
3. **POST** `/api/products` with **Body → raw → JSON**:
   ```json
   { "name": "Desk lamp", "category": "Home", "price": 1200 }
   ```
   Expect `201 Created` and the new product with its assigned ID.
4. **PUT** `/api/products/4` with **Body → raw → JSON** to edit it:
   ```json
   { "name": "LED desk lamp", "category": "Home", "price": 1350 }
   ```
   Replace `4` with the ID returned by your POST request. Expect `200 OK`.
5. **DELETE** `/api/products/4` to delete it. Expect `204 No Content`.

POST and PUT require non-empty `name` and `category` fields and a finite
non-negative `price`. Invalid data returns `400 Bad Request`; an unknown
product ID returns `404 Not Found`.

## Dashboard features

- Product cards, summary totals, dynamic product detail dialog, and cart count
  and value.
- Add, edit, and confirmed delete operations.
- Combined case-insensitive name search, category filter, and min/max price
  filters.
- Name and ascending/descending price sorting, plus pagination.
- Loading, validation, API error, empty-result, and success feedback.

## Troubleshooting

- **Connection refused / unable to load products:** make sure the backend
  terminal is still running at port 5000, then use the dashboard's Retry
  button or reload the frontend.
- **CORS error:** the backend enables CORS with `cors()`. Restart the backend
  after changing its configuration and open the frontend from the Vite URL.
- **Missing dependencies / `vite` or `express` not found:** run `npm install`
  from the matching `shopping-frontend` or `shopping-backend` folder.
- **Port already in use:** stop the other app using the port, then restart this
  project. The API is configured for port 5000; Vite will print an alternate
  frontend URL if port 5173 is occupied.
