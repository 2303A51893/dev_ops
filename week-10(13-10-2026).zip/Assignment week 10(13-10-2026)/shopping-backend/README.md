# Shopping Product API

Express REST API for the Online Shopping Product Dashboard. It runs at
`http://localhost:5000` and keeps its sample data in memory.

## Start the API

```powershell
cd shopping-backend
npm install
npm run dev
```

Use `npm start` instead of `npm run dev` to run without automatic restarts.

## Endpoints

| Method | URL | Result |
| --- | --- | --- |
| GET | `/api/products` | Return all products |
| GET | `/api/products/1` | Return one product |
| POST | `/api/products` | Create a product (returns `201`) |
| PUT | `/api/products/1` | Replace a product's name, category, and price |
| DELETE | `/api/products/1` | Delete a product (returns `204`) |

POST and PUT expect JSON such as:

```json
{
  "name": "Desk lamp",
  "category": "Home",
  "price": 1200
}
```

Name and category must not be blank; price must be a finite number greater than
or equal to zero. Invalid input returns `400`; a missing product returns `404`.
Products are stored only in an in-memory array, so added, edited, and deleted
products reset to the initial samples whenever the backend restarts.
