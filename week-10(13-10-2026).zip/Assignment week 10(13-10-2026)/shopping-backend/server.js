const express = require("express");
const cors = require("cors");

const app = express();
const PORT = 5000;

let products = [
  { id: 1, name: "Laptop", category: "Electronics", price: 60000 },
  { id: 2, name: "Headphones", category: "Electronics", price: 2000 },
  { id: 3, name: "Backpack", category: "Accessories", price: 1500 },
];
let nextId = 4;

app.use(cors());
app.use(express.json());

function validateProduct(body) {
  const errors = {};
  const price =
    typeof body.price === "string" ? body.price.trim() : body.price;

  if (typeof body.name !== "string" || !body.name.trim()) {
    errors.name = "Product name is required.";
  }

  if (typeof body.category !== "string" || !body.category.trim()) {
    errors.category = "Category is required.";
  }
  if (
    (typeof price !== "number" && typeof price !== "string") ||
    price === "" ||
    !Number.isFinite(Number(price)) ||
    Number(price) < 0
  ) {
    errors.price = "Price must be a valid number greater than or equal to 0.";
  }

  return errors;
}

function getProductId(value) {
  const id = Number(value);
  return Number.isInteger(id) && id > 0 ? id : null;
}

app.get("/api/products", (req, res) => {
  res.json(products);
});

app.get("/api/products/:id", (req, res) => {
  const id = getProductId(req.params.id);
  if (id === null) {
    return res.status(400).json({ message: "Product ID must be a positive integer." });
  }

  const product = products.find((item) => item.id === id);
  if (!product) {
    return res.status(404).json({ message: "Product not found." });
  }

  return res.json(product);
});

app.post("/api/products", (req, res) => {
  const errors = validateProduct(req.body || {});
  if (Object.keys(errors).length > 0) {
    return res.status(400).json({ message: "Please correct the product details.", errors });
  }

  const product = {
    id: nextId++,
    name: req.body.name.trim(),
    category: req.body.category.trim(),
    price: Number(req.body.price),
  };

  products.push(product);
  return res.status(201).json(product);
});

app.put("/api/products/:id", (req, res) => {
  const id = getProductId(req.params.id);
  if (id === null) {
    return res.status(400).json({ message: "Product ID must be a positive integer." });
  }

  const productIndex = products.findIndex((item) => item.id === id);
  if (productIndex === -1) {
    return res.status(404).json({ message: "Product not found." });
  }

  const errors = validateProduct(req.body || {});
  if (Object.keys(errors).length > 0) {
    return res.status(400).json({ message: "Please correct the product details.", errors });
  }

  products[productIndex] = {
    id,
    name: req.body.name.trim(),
    category: req.body.category.trim(),
    price: Number(req.body.price),
  };

  return res.json(products[productIndex]);
});

app.delete("/api/products/:id", (req, res) => {
  const id = getProductId(req.params.id);
  if (id === null) {
    return res.status(400).json({ message: "Product ID must be a positive integer." });
  }

  const productIndex = products.findIndex((item) => item.id === id);
  if (productIndex === -1) {
    return res.status(404).json({ message: "Product not found." });
  }

  products.splice(productIndex, 1);
  return res.status(204).end();
});

app.use((error, req, res, next) => {
  if (error instanceof SyntaxError && error.status === 400 && "body" in error) {
    return res.status(400).json({ message: "Request body must contain valid JSON." });
  }

  console.error(error);
  return res.status(500).json({ message: "An unexpected server error occurred." });
});

app.listen(PORT, () => {
  console.log(`Shopping API is running at http://localhost:${PORT}`);
});
