import { useEffect, useMemo, useState } from "react";
import Header from "./components/Header.jsx";
import ProductDetails from "./components/ProductDetails.jsx";
import ProductForm from "./components/ProductForm.jsx";
import ProductList from "./components/ProductList.jsx";
import SearchBar from "./components/SearchBar.jsx";
import {
  createProduct,
  deleteProduct,
  getErrorMessage,
  getProducts,
  updateProduct,
} from "./services/api.js";

const PAGE_SIZE = 6;
const initialFilters = {
  search: "",
  category: "",
  minPrice: "",
  maxPrice: "",
  sort: "name",
};

function formatPrice(value) {
  return Number(value).toLocaleString("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  });
}

export default function App() {
  const [products, setProducts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [loadError, setLoadError] = useState("");
  const [notice, setNotice] = useState("");
  const [filters, setFilters] = useState(initialFilters);
  const [editingProduct, setEditingProduct] = useState(null);
  const [selectedProductId, setSelectedProductId] = useState(null);
  const [cart, setCart] = useState({});
  const [page, setPage] = useState(1);

  async function loadProducts() {
    setIsLoading(true);
    setLoadError("");
    try {
      const data = await getProducts();
      setProducts(data);
    } catch (error) {
      setLoadError(getErrorMessage(error));
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    loadProducts();
  }, []);

  const categories = useMemo(
    () => [...new Set(products.map((product) => product.category))].sort((a, b) => a.localeCompare(b)),
    [products],
  );

  const filteredProducts = useMemo(() => {
    const search = filters.search.trim().toLowerCase();
    const min = filters.minPrice === "" ? null : Number(filters.minPrice);
    const max = filters.maxPrice === "" ? null : Number(filters.maxPrice);
    const matches = products.filter((product) => {
      const matchesName = product.name.toLowerCase().includes(search);
      const matchesCategory = !filters.category || product.category === filters.category;
      const matchesMin = min === null || product.price >= min;
      const matchesMax = max === null || product.price <= max;
      return matchesName && matchesCategory && matchesMin && matchesMax;
    });

    return matches.sort((a, b) => {
      if (filters.sort === "price-asc") return a.price - b.price;
      if (filters.sort === "price-desc") return b.price - a.price;
      return a.name.localeCompare(b.name);
    });
  }, [products, filters]);

  const pageCount = Math.max(1, Math.ceil(filteredProducts.length / PAGE_SIZE));
  const visibleProducts = filteredProducts.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);
  const selectedProduct = products.find((product) => product.id === selectedProductId);
  const cartEntries = products.filter((product) => cart[product.id]);
  const cartCount = Object.values(cart).reduce((total, quantity) => total + quantity, 0);
  const cartTotal = cartEntries.reduce((total, product) => total + product.price * cart[product.id], 0);
  const inventoryValue = products.reduce((total, product) => total + product.price, 0);

  function updateFilter(name, value) {
    setFilters((current) => ({ ...current, [name]: value }));
    setPage(1);
  }

  async function saveProduct(product) {
    try {
      if (editingProduct) {
        await updateProduct(editingProduct.id, product);
        setNotice(`${product.name} was updated successfully.`);
        setEditingProduct(null);
      } else {
        await createProduct(product);
        setNotice(`${product.name} was added to your catalog.`);
      }
      await loadProducts();
    } catch (error) {
      throw new Error(getErrorMessage(error));
    }
  }

  async function removeProduct(product) {
    const confirmed = window.confirm(`Delete "${product.name}" from your products?`);
    if (!confirmed) return;

    setNotice("");
    try {
      await deleteProduct(product.id);
      setProducts((current) => current.filter((item) => item.id !== product.id));
      setCart((current) => {
        const next = { ...current };
        delete next[product.id];
        return next;
      });
      setEditingProduct((current) => (current?.id === product.id ? null : current));
      setSelectedProductId((current) => (current === product.id ? null : current));
      setNotice(`${product.name} was deleted.`);
    } catch (error) {
      setLoadError(getErrorMessage(error));
    }
  }

  function addToCart(product) {
    setCart((current) => ({ ...current, [product.id]: (current[product.id] || 0) + 1 }));
    setNotice(`${product.name} added to cart.`);
  }

  function startEditing(product) {
    setEditingProduct(product);
    setNotice("");
    document.getElementById("product-form")?.scrollIntoView({ behavior: "smooth", block: "center" });
  }

  function resetFilters() {
    setFilters(initialFilters);
    setPage(1);
  }

  return (
    <div className="app-shell">
      <Header cartCount={cartCount} />
      <main className="dashboard">
        <section className="welcome-row">
          <div>
            <span className="eyebrow">YOUR STORE AT A GLANCE</span>
            <h2>Good day, store manager <span aria-hidden="true">✦</span></h2>
            <p>Keep your catalog fresh and your customers happy.</p>
          </div>
          <div className="today-chip"><span className="status-dot" /> Store is online</div>
        </section>

        <section className="summary-grid" aria-label="Store summary">
          <article className="summary-card">
            <span className="summary-icon blue" aria-hidden="true">▦</span>
            <div><span className="summary-label">Total products</span><strong>{products.length}</strong></div>
            <span className="summary-foot">Items in your catalog</span>
          </article>
          <article className="summary-card">
            <span className="summary-icon violet" aria-hidden="true">◈</span>
            <div><span className="summary-label">Categories</span><strong>{categories.length}</strong></div>
            <span className="summary-foot">Unique collections</span>
          </article>
          <article className="summary-card">
            <span className="summary-icon green" aria-hidden="true">₹</span>
            <div><span className="summary-label">Inventory value</span><strong>{formatPrice(inventoryValue)}</strong></div>
            <span className="summary-foot">Combined product value</span>
          </article>
          <article className="summary-card">
            <span className="summary-icon amber" aria-hidden="true">▣</span>
            <div><span className="summary-label">Cart total</span><strong>{formatPrice(cartTotal)}</strong></div>
            <span className="summary-foot">{cartCount} {cartCount === 1 ? "item" : "items"} in your cart</span>
          </article>
        </section>

        {notice && <div className="notice-banner" role="status"><span>✓</span>{notice}<button onClick={() => setNotice("")} aria-label="Dismiss message">×</button></div>}
        {loadError && (
          <div className="error-banner" role="alert">
            <span>{isLoading ? "Loading products..." : "Unable to load products. Please try again."}</span>
            <span>{loadError}</span>
            {!isLoading && <button className="button button-quiet button-small" onClick={loadProducts}>Retry</button>}
          </div>
        )}

        <div className="workspace-layout">
          <div className="catalog-column">
            <div className="section-title-row">
              <div><span className="eyebrow">PRODUCT CATALOG</span><h2>All products <span className="count-badge">{filteredProducts.length}</span></h2></div>
              <span className="catalog-note">Manage your store inventory</span>
            </div>
            <SearchBar filters={filters} categories={categories} onChange={updateFilter} onReset={resetFilters} />
            {isLoading ? (
              <div className="loading-state" role="status"><span className="spinner" />Loading products...</div>
            ) : loadError ? null : (
              <>
                <ProductList
                  products={visibleProducts}
                  onEdit={startEditing}
                  onDelete={removeProduct}
                  onView={(product) => setSelectedProductId(product.id)}
                  onAddToCart={addToCart}
                />
                {filteredProducts.length > 0 && (
                  <nav className="pagination" aria-label="Product pages">
                    <span>Showing {((page - 1) * PAGE_SIZE) + 1}–{Math.min(page * PAGE_SIZE, filteredProducts.length)} of {filteredProducts.length}</span>
                    <div>
                      <button className="button button-quiet button-small" onClick={() => setPage((current) => Math.max(1, current - 1))} disabled={page === 1}>← Previous</button>
                      <span className="page-indicator">Page {page} of {pageCount}</span>
                      <button className="button button-quiet button-small" onClick={() => setPage((current) => Math.min(pageCount, current + 1))} disabled={page === pageCount}>Next →</button>
                    </div>
                  </nav>
                )}
              </>
            )}
          </div>
          <aside className="management-column">
            <ProductForm
              product={editingProduct}
              onSave={saveProduct}
              onCancel={() => setEditingProduct(null)}
            />
            <section className="tip-card">
              <span className="tip-icon" aria-hidden="true">✦</span>
              <div><strong>Quick tip</strong><p>Use search and filters together to find products faster. Your changes are saved while the API server is running.</p></div>
            </section>
          </aside>
        </div>
      </main>
      <footer className="site-footer">
        <span>SHOPWISE <span aria-hidden="true">•</span> PRODUCT MANAGEMENT</span>
        <span>Product data resets when the backend restarts.</span>
      </footer>
      <ProductDetails product={selectedProduct} onClose={() => setSelectedProductId(null)} />
    </div>
  );
}
