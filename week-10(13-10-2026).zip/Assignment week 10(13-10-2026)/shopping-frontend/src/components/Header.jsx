export default function Header({ cartCount }) {
  return (
    <header className="site-header">
      <a className="brand" href="/" aria-label="Shopwise dashboard home">
        <span className="brand-mark" aria-hidden="true">
          S
        </span>
        <span>shopwise</span>
      </a>
      <div className="header-title">
        <span className="eyebrow">PRODUCT MANAGEMENT</span>
        <h1>Online Shopping Product Dashboard</h1>
      </div>
      <div className="cart-pill" aria-label={`${cartCount} items in cart`}>
        <span aria-hidden="true">▣</span>
        <span>Cart</span>
        <strong>{cartCount}</strong>
      </div>
    </header>
  );
}
