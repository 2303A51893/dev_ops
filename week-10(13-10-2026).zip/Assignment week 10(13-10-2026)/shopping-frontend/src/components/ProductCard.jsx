const categoryIcons = {
  Electronics: "⌘",
  Accessories: "◇",
  Clothing: "✳",
  Home: "⌂",
};

export default function ProductCard({
  product,
  onEdit,
  onDelete,
  onView,
  onAddToCart,
}) {
  return (
    <article className="product-card">
      <div className="product-art" aria-hidden="true">
        <span className="product-art-icon">
          {categoryIcons[product.category] || "✦"}
        </span>
        <span className="art-caption">{product.category}</span>
        <span className="art-orbit" />
      </div>
      <div className="product-card-body">
        <div className="product-card-heading">
          <div>
            <span className="category-label">{product.category}</span>
            <h3>{product.name}</h3>
          </div>
          <strong className="product-price">
            {Number(product.price).toLocaleString("en-IN", {
              style: "currency",
              currency: "INR",
              maximumFractionDigits: 0,
            })}
          </strong>
        </div>
        <div className="card-actions">
          <button className="button button-primary button-small" onClick={() => onAddToCart(product)}>
            Add to cart
          </button>
          <button className="button button-quiet button-small" onClick={() => onView(product)}>
            View
          </button>
          <button className="icon-button" aria-label={`Edit ${product.name}`} onClick={() => onEdit(product)}>
            Edit
          </button>
          <button className="icon-button danger-text" aria-label={`Delete ${product.name}`} onClick={() => onDelete(product)}>
            Delete
          </button>
        </div>
      </div>
    </article>
  );
}
