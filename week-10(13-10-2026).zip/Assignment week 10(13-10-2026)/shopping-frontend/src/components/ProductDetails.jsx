export default function ProductDetails({ product, onClose }) {
  if (!product) return null;

  return (
    <div className="modal-backdrop" role="presentation" onMouseDown={onClose}>
      <section
        className="details-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="details-title"
        onMouseDown={(event) => event.stopPropagation()}
      >
        <button className="modal-close" type="button" onClick={onClose} aria-label="Close product details">
          ×
        </button>
        <span className="eyebrow">PRODUCT DETAILS</span>
        <div className="details-art" aria-hidden="true">✦</div>
        <span className="category-label">{product.category}</span>
        <h2 id="details-title">{product.name}</h2>
        <p className="details-id">Product ID: #{product.id}</p>
        <p className="details-price">
          {Number(product.price).toLocaleString("en-IN", {
            style: "currency",
            currency: "INR",
            maximumFractionDigits: 2,
          })}
        </p>
        <p className="details-description">
          {product.name} is available in your {product.category} collection.
        </p>
      </section>
    </div>
  );
}
