import { useEffect, useState } from "react";

const emptyForm = { name: "", category: "", price: "" };

export default function ProductForm({ product, onSave, onCancel }) {
  const [form, setForm] = useState(emptyForm);
  const [errors, setErrors] = useState({});
  const [submitError, setSubmitError] = useState("");
  const [isSaving, setIsSaving] = useState(false);
  const isEditing = Boolean(product);

  useEffect(() => {
    setForm(
      product
        ? { name: product.name, category: product.category, price: String(product.price) }
        : emptyForm,
    );
    setErrors({});
    setSubmitError("");
  }, [product]);

  function validate() {
    const nextErrors = {};
    const price = Number(form.price);

    if (!form.name.trim()) nextErrors.name = "Enter a product name.";
    if (!form.category.trim()) nextErrors.category = "Enter a category.";
    if (form.price.trim() === "" || !Number.isFinite(price) || price < 0) {
      nextErrors.price = "Enter a valid price of 0 or more.";
    }

    return nextErrors;
  }

  async function handleSubmit(event) {
    event.preventDefault();
    const nextErrors = validate();
    setErrors(nextErrors);
    setSubmitError("");
    if (Object.keys(nextErrors).length > 0) return;

    setIsSaving(true);
    try {
      await onSave({
        name: form.name.trim(),
        category: form.category.trim(),
        price: Number(form.price),
      });
      setForm(emptyForm);
      setErrors({});
    } catch (error) {
      setSubmitError(error.message || String(error));
    } finally {
      setIsSaving(false);
    }
  }

  function updateField(event) {
    const { name, value } = event.target;
    setForm((current) => ({ ...current, [name]: value }));
    setErrors((current) => ({ ...current, [name]: "" }));
  }

  return (
    <section className="panel form-panel" id="product-form">
      <div className="panel-heading">
        <div>
          <span className="eyebrow">CATALOG TOOLS</span>
          <h2>{isEditing ? "Edit product" : "Add a product"}</h2>
        </div>
        <span className="panel-icon" aria-hidden="true">
          {isEditing ? "✎" : "+"}
        </span>
      </div>
      <p className="panel-description">
        {isEditing ? "Update the details below." : "Add a new item to your catalog."}
      </p>
      <form onSubmit={handleSubmit} noValidate>
        <label className="field-label" htmlFor="product-name">
          Product name
        </label>
        <input
          id="product-name"
          name="name"
          value={form.name}
          onChange={updateField}
          placeholder="e.g. Wireless speaker"
          aria-invalid={Boolean(errors.name)}
          aria-describedby={errors.name ? "name-error" : undefined}
        />
        {errors.name && <span className="field-error" id="name-error">{errors.name}</span>}

        <label className="field-label" htmlFor="product-category">
          Category
        </label>
        <input
          id="product-category"
          name="category"
          value={form.category}
          onChange={updateField}
          placeholder="e.g. Electronics"
          aria-invalid={Boolean(errors.category)}
          aria-describedby={errors.category ? "category-error" : undefined}
        />
        {errors.category && <span className="field-error" id="category-error">{errors.category}</span>}

        <label className="field-label" htmlFor="product-price">
          Price <span className="field-hint">(INR)</span>
        </label>
        <div className="price-input">
          <span aria-hidden="true">₹</span>
          <input
            id="product-price"
            name="price"
            type="number"
            min="0"
            step="0.01"
            value={form.price}
            onChange={updateField}
            placeholder="0.00"
            aria-invalid={Boolean(errors.price)}
            aria-describedby={errors.price ? "price-error" : undefined}
          />
        </div>
        {errors.price && <span className="field-error" id="price-error">{errors.price}</span>}
        {submitError && <div className="inline-error" role="alert">{submitError}</div>}
        <div className="form-actions">
          <button className="button button-primary form-submit" type="submit" disabled={isSaving}>
            {isSaving ? "Saving..." : isEditing ? "Save changes" : "Add product"}
          </button>
          {isEditing && (
            <button className="button button-quiet" type="button" onClick={onCancel} disabled={isSaving}>
              Cancel
            </button>
          )}
        </div>
      </form>
    </section>
  );
}
