import ProductCard from "./ProductCard.jsx";

export default function ProductList({
  products,
  onEdit,
  onDelete,
  onView,
  onAddToCart,
}) {
  if (products.length === 0) {
    return (
      <div className="empty-state">
        <span className="empty-icon" aria-hidden="true">
          ⌕
        </span>
        <h3>No products found.</h3>
        <p>Try changing your search or filters to find what you need.</p>
      </div>
    );
  }

  return (
    <div className="product-grid">
      {products.map((product) => (
        <ProductCard
          key={product.id}
          product={product}
          onEdit={onEdit}
          onDelete={onDelete}
          onView={onView}
          onAddToCart={onAddToCart}
        />
      ))}
    </div>
  );
}
