export default function SearchBar({
  filters,
  categories,
  onChange,
  onReset,
}) {
  const min = filters.minPrice === "" ? null : Number(filters.minPrice);
  const max = filters.maxPrice === "" ? null : Number(filters.maxPrice);
  const priceError = min !== null && max !== null && min > max;

  return (
    <section className="panel filter-panel" aria-label="Search and filter products">
      <div className="filter-search">
        <label className="field-label" htmlFor="product-search">Search products</label>
        <div className="search-input">
          <span aria-hidden="true">⌕</span>
          <input
            id="product-search"
            type="search"
            placeholder="Search by product name..."
            value={filters.search}
            onChange={(event) => onChange("search", event.target.value)}
          />
        </div>
      </div>
      <div className="filter-controls">
        <div>
          <label className="field-label" htmlFor="category-filter">Category</label>
          <select
            id="category-filter"
            value={filters.category}
            onChange={(event) => onChange("category", event.target.value)}
          >
            <option value="">All categories</option>
            {categories.map((category) => (
              <option key={category} value={category}>{category}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="field-label" htmlFor="min-price">Min price</label>
          <input
            id="min-price"
            type="number"
            min="0"
            placeholder="₹ 0"
            value={filters.minPrice}
            onChange={(event) => onChange("minPrice", event.target.value)}
          />
        </div>
        <div>
          <label className="field-label" htmlFor="max-price">Max price</label>
          <input
            id="max-price"
            type="number"
            min="0"
            placeholder="No limit"
            value={filters.maxPrice}
            onChange={(event) => onChange("maxPrice", event.target.value)}
          />
        </div>
        <div>
          <label className="field-label" htmlFor="product-sort">Sort by</label>
          <select
            id="product-sort"
            value={filters.sort}
            onChange={(event) => onChange("sort", event.target.value)}
          >
            <option value="name">Name: A to Z</option>
            <option value="price-asc">Price: Low to high</option>
            <option value="price-desc">Price: High to low</option>
          </select>
        </div>
        <button className="button button-quiet reset-button" onClick={onReset} type="button">
          Reset
        </button>
      </div>
      {priceError && (
        <p className="filter-error" role="alert">Minimum price cannot be greater than maximum price.</p>
      )}
    </section>
  );
}
