import axios from "axios";

const api = axios.create({
  baseURL: "http://localhost:5000/api",
  headers: {
    "Content-Type": "application/json",
  },
});

export function getErrorMessage(error) {
  if (error.response?.data?.message) {
    return error.response.data.message;
  }

  if (error.request) {
    return "Unable to reach the server. Check that the backend is running at http://localhost:5000.";
  }

  return error.message || "Something went wrong. Please try again.";
}

export const getProducts = async () => (await api.get("/products")).data;

export const getProduct = async (id) => (await api.get(`/products/${id}`)).data;

export const createProduct = async (product) =>
  (await api.post("/products", product)).data;

export const updateProduct = async (id, product) =>
  (await api.put(`/products/${id}`, product)).data;

export const deleteProduct = async (id) => {
  await api.delete(`/products/${id}`);
};
